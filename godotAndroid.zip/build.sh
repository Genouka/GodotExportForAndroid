#配置Android环境
chmod +x gradlew
./gradlew
sdkmanager "platform-tools" "build-tools;30.0.3" "platforms;android-31" "cmdline-tools;latest" "cmake;3.10.2.4988404" "ndk;21.4.7075529"
#下载并安装Godot
wget https://github.com/godotengine/godot/releases/download/4.1.1-stable/Godot_v4.1.1-stable_linux.x86_64.zip
unzip Godot_v4.1.1-stable_linux.x86_64.zip
rm Godot_v4.1.1-stable_linux.x86_64.zip
mv Godot_v4.1.1-stable_linux.x86_64 Godot
chmod +x Godot
#下载构建模板
wget https://downloads.tuxfamily.org/godotengine/4.1.1/Godot_v4.1.1-stable_export_templates.tpz
# 构建项目
mkdir release
./Godot --headless --path ./example/ --export-release Android release/game.apk
